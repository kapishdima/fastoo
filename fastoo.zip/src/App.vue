<template>
  <router-view />
</template>

<style lang="scss">
@import '@/app/style/index.scss';
</style>
